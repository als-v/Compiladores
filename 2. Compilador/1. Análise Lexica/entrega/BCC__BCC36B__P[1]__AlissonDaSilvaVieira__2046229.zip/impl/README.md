# Análise léxica da linguagem TPP

## Bibliotecas utilizadas:
- ply.lex: é um módulo da biblioteca ply, que é usado para o processo da análise léxica.
- sys: Este módulo fornece acesso a algumas variáveis usadas ou mantidas pelo interpretador e a funções que interagem fortemente com o interpretador.

## Para rodar deve-se executar o comando:
	python3 lex.py [arquivo.tpp] [d]
- arquivo.tpp: parâmetro obrigatorio, que indica o arquivo a ser utilizado para a análise;
- d: parâmetro opcional, que indica se a saída deve ser detalhada ou não.