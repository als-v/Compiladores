#include <stdio.h>

void escrevaInteiro(int i) {
  printf("%d\n", i);
}

int leiaInteiro() {
  int i;

  scanf("%d", &i);

  return i;
}

void escrevaFlutuante(float i) {
  printf("%f\n", i);
}

float leiaFlutuante() {
  float i;

  scanf("%f", &i);

  return i;
}


